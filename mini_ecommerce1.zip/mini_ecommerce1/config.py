import os

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "my_secret_key_123")
    ADMIN_SECRET_KEY = os.environ.get("ADMIN_SECRET_KEY", "Sadvistore@2026#Admin")

    DB_TYPE = os.environ.get("DB_TYPE", "mysql")   # mysql locally, sqlite on deployment

    MYSQL_HOST = os.environ.get("MYSQL_HOST", "localhost")
    MYSQL_USER = os.environ.get("MYSQL_USER", "root")
    MYSQL_PASSWORD = os.environ.get("MYSQL_PASSWORD", "sadvi@025")
    MYSQL_DB = os.environ.get("MYSQL_DB", "mini_ecommerce")

    SQLITE_DB = os.environ.get("SQLITE_DB", "site.db")

    MAIL_SERVER = "smtp.gmail.com"
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USE_SSL = False
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME", "allivo.notifications@gmail.com")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD", "uvncgbsbvzookatd")
    MAIL_DEFAULT_SENDER = ("Allivo", os.environ.get("MAIL_USERNAME", "allivo.notifications@gmail.com"))

 